using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {

	private Animator anim;
	private CharacterController controller;
	public GameController gameController;

	public static bool lostLife = false;

	public bool grounded;
	public bool jump;
	public float speed = 2;	/* Asset Default: 600.0f */
	public float turnSpeed = 400.0f;
	public float gravity = 25.0f;	/* Asset Default: 20.0f */
	private Vector3 moveDirection = Vector3.zero;
	private int defaultYPosition = 1;
	private int currentYPosition;

	void Start() {

		GameObject gameControllerObject = GameObject.FindWithTag("GameController");
		if(gameControllerObject != null) {

			gameController = gameControllerObject.GetComponent<GameController>();
			Debug.Log("Got GameController Component in Player Script.");
		}

		controller = GetComponent<CharacterController>();
		anim = gameObject.GetComponentInChildren<Animator>();
		grounded = true;
		jump = false;
	}

	void Update() {
		
		if(controller.isGrounded) {

			calculateLevelInterchangeScore();

			moveDirection = new Vector3(0, 0, Input.GetAxis("Vertical"));
			moveDirection = transform.forward * Input.GetAxis("Vertical") * speed;

			if (Input.GetKey("w")) {
			
				anim.SetInteger ("AnimationPar", 1);
			}  
			else if (Input.GetKey("space")) {
			
				jump = true;
				
				anim.SetBool("Grounded", true);
				anim.SetInteger ("AnimationPar", 2);
				moveDirection.y = 6;
				
				jump = false;		
			}
			else {

				anim.SetInteger ("AnimationPar", 0);
			}
		}
		else {

			if(RespawnPlayer.fellInSpace == true) {

				gameController.UpdateLives(-1);
				
				RespawnPlayer.fellInSpace = false;
			}
		}
		
		float turn = Input.GetAxis("Horizontal");
		transform.Rotate(0, turn * turnSpeed * Time.deltaTime, 0);
		controller.Move(moveDirection * Time.deltaTime);
		moveDirection.y -= gravity * Time.deltaTime;
	}

	void calculateLevelInterchangeScore() {

		currentYPosition = (int) Math.Truncate(transform.position.y);

		if(defaultYPosition != currentYPosition) {
			
			if(defaultYPosition < currentYPosition) {
				
				Debug.Log("Got to level: " + currentYPosition);

				if(currentYPosition == GetInput.currentScale) {

					gameController.UpdatePoints(100);
					gameController.UpdateLives(1);
				}
				else {

					gameController.UpdatePoints(10);
				}
			}
			else if (defaultYPosition > currentYPosition) {
				
				Debug.Log("Fell on level: " + currentYPosition);
				gameController.UpdatePoints(-(((defaultYPosition - currentYPosition) * 10) - 10));
			}

			defaultYPosition = (int) Math.Truncate(transform.position.y);
		}
	}
}
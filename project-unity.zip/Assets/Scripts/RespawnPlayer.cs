﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RespawnPlayer : MonoBehaviour
{
    [SerializeField] private Player respawnPlayer;

    public static bool fellInSpace = false;

    void Start() {

    	GameObject respawnPlayerObject = GameObject.FindWithTag("Player");
    	if (respawnPlayerObject != null) {

    		respawnPlayer = respawnPlayerObject.GetComponent<Player>();
    		Debug.Log("Got Player Component in RespawnPlayer Script.");
    	}
    }

    void OnTriggerEnter(Collider other) {

    	Debug.Log("Astonaut Hit Space Floor.");

    	fellInSpace = true;

    	respawnPlayer.transform.position = new Vector3(GetInput.currentScale/2, GetInput.currentScale/2, GetInput.currentScale/2);
    	Debug.Log("Astronaut in place: " + respawnPlayer.transform.position);
    }
}
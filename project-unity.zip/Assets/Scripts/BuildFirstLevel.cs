using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[RequireComponent(typeof(MeshFilter))]
[RequireComponent(typeof(MeshRenderer))]

public class BuildFirstLevel : GetInput {

	public GameObject[, ,] Cubes = new GameObject[GetInput.currentScale, GetInput.currentScale, GetInput.currentScale];

	public GameObject DirectionalLight1 = null;
    public GameObject DirectionalLight2 = null;

    public BoxCollider SpaceIdentifierPrefab = null;

	public Color red = Color.red;
    public Color green = Color.green;
    public Color blue = Color.blue;
    public Color yellow = Color.yellow;
    public Color magenta = Color.magenta;
    public Color cyan = Color.cyan;

    List<Color> colorList = new List<Color>()
     {
        Color.cyan,
        Color.red,
        Color.green,
        Color.blue,
        Color.yellow,
        Color.magenta,
     };

     public void Awake() {

 		Debug.Log("Building Floor, Walls and Lighting in scale " + GetInput.currentScale);
 		createMesh(GetInput.currentScale);
    	createBoundaries(GetInput.currentScale);
    	setLighting(GetInput.currentScale);
    	createRespawnTrigger(GetInput.currentScale);
     }

    void createMesh(int scale)
    {

        for (int x = 0; x < scale; x++)
        {
            for (int y = 0; y < scale; y++)
            {
                Cubes[x, y, 1] = GameObject.CreatePrimitive(PrimitiveType.Cube);
                Cubes[x, y, 1].transform.localScale = new Vector3(1, 1, 1);
                Cubes[x, y, 1].transform.position = new Vector3(x, 1, y);
                if (x == scale / 2 && y == scale / 2)
                {
                    Cubes[x, y, 1].GetComponent<Renderer>().material.color = Color.magenta;
                }
                else
                {
                    Cubes[x, y, 1].GetComponent<Renderer>().material.color = colorList[Random.Range(0, colorList.Count)];
                }

                Cubes[x, y, 0] = null;
            }
        }
    }

    void createBoundaries(int scale) {

    	GameObject[] boundary = new GameObject[4];

    	for(int i = 0; i < 4; i++) {

    		boundary[i] = GameObject.CreatePrimitive(PrimitiveType.Cube);
    		boundary[i].transform.localScale = new Vector3(1, scale, scale);

    		if(i % 2 != 0) {	/* Every other element */

    			boundary[i].transform.rotation = Quaternion.Euler(0, 90, 0);	/* rotated elements are boundary[1], boundary[3] */
    		}
    	}
    	
    	boundary[0].transform.position = new Vector3(-1, scale/2, scale/2);	/* Left Wall */
    	boundary[0].name = "Left Wall";
    	boundary[0].GetComponent<MeshRenderer>().enabled = false;
    	boundary[1].transform.position = new Vector3(scale/2, scale/2, -1);	/* Bottom Wall */
    	boundary[1].name = "Bottom Wall";
    	boundary[1].GetComponent<MeshRenderer>().enabled = false;
    	boundary[2].transform.position = new Vector3(scale, scale/2, scale/2);	/* Right Wall */
    	boundary[2].name = "Right Wall";
    	boundary[2].GetComponent<MeshRenderer>().enabled = false;
    	boundary[3].transform.position = new Vector3(scale/2, scale/2, scale);	/* Top Wall */
    	boundary[3].name = "Top Wall";
    	boundary[3].GetComponent<MeshRenderer>().enabled = false;	/* So they are invisible */
    }

    void setLighting(int scale) {

    	Debug.Log("Placing Directional Light 1");
        Debug.Log("Placing Directional Light 2");

        Instantiate(DirectionalLight1, new Vector3(0, 0, scale), Quaternion.Euler(new Vector3(35, -225, 0)));
        Instantiate(DirectionalLight2, new Vector3(scale, 0, 0), Quaternion.Euler(new Vector3(35, -45, 0)));
    }

    void createRespawnTrigger(int scale) {

    	BoxCollider SpaceIdentifier = (BoxCollider) Instantiate(SpaceIdentifierPrefab, new Vector3(0, 0, 0), Quaternion.identity);
    	SpaceIdentifier.center = new Vector3(scale / 2, 0, scale / 2);
    	SpaceIdentifier.size = new Vector3(scale*4, 1, scale*4);

    	Debug.Log("Created Respawn Trigger.");
    }
}
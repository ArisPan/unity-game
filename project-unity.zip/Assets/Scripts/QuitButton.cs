﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuitButton : MonoBehaviour
{
    
    public void quitGame() {

    	Debug.Log("Quited Game.");
    	Application.Quit();
    }
}

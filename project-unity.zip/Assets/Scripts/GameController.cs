﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour {

	public Text LivesText;
	public int LivesCounter;
	public Text PointsText;
	public int PointsCounter;

	void Start() {

		UpdateLives(4);
		UpdatePoints(100);
	}

	public void UpdateLives(int newLivesCount) {

		LivesCounter += newLivesCount;
		if(LivesCounter == 0) {

			Debug.Log("Game Over.");
		}

		LivesText.text = "" + LivesCounter;
	}

	public void UpdatePoints(int newPointsCount) {

		PointsCounter += newPointsCount;
		if(PointsCounter <= 0) {

			PointsCounter = 100;
			UpdateLives(-1);
		}

		PointsText.text = "" + PointsCounter;
	}
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnPlayer : MonoBehaviour
{
	public GameObject player;
	public GameObject playerObject;	

    void Start() {
        
        Debug.Log("New Player Position: " + GetInput.currentScale/2);

        playerObject = Instantiate(player, new Vector3(GetInput.currentScale/2, GetInput.currentScale/2, GetInput.currentScale/2), Quaternion.identity);
    }
}
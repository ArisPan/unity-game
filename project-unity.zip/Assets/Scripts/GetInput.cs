using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;

public class GetInput : MonoBehaviour {

	public static int currentScale;

	public void getInput(string scale) {

		if(int.TryParse(scale, out currentScale)) {

			Debug.Log("You entered " + currentScale);
		}
		else {

			Debug.Log("Invalid input.");
		}
	}
}
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEngine.SceneManagement;

public class ChangeScene : MonoBehaviour {

	public void nextScene() {

		Debug.Log("Entering scene " + SceneManager.GetActiveScene().buildIndex + 1);
		SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);	/* Loads the next scene. */
	}
}
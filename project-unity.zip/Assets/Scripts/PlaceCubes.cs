﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaceCubes : MonoBehaviour
{
    public Player spawnedPlayer;
    public GameController gameController2;

    public List<GameObject> placedCubes = new List<GameObject>();
    public List<GameObject> placedCylinders = new List<GameObject>();

    private Vector3 spawnedPlayerPosition;
    private Vector3 spawnedPlayerDirection;
    private Quaternion spawnedPlayerRotation;

    List<Color> colorList = new List<Color>()
     {
        Color.cyan,
        Color.red,
        Color.green,
        Color.blue,
        Color.yellow,
        Color.magenta,
     };

    void Start() {

    	GameObject gameControllerObject = GameObject.FindWithTag("GameController");
		if(gameControllerObject != null) {

			gameController2 = gameControllerObject.GetComponent<GameController>();
			Debug.Log("Got GameController Component in PlaceCubes Script.");
		}
		else {

    		Debug.Log("Cannot find GameController script.");
    	}

    	GameObject spawnedPlayerObject = GameObject.FindWithTag("Player");
    	if(spawnedPlayerObject != null) {

    		spawnedPlayer = spawnedPlayerObject.GetComponent<Player>();
    		Debug.Log("Got reference of spawnedPlayer in PlaceCubes script.");
    	}
    	else {

    		Debug.Log("Cannot find Player script.");
    	}
    }

    void Update() {

    	spawnedPlayerPosition = spawnedPlayer.transform.position;
    	spawnedPlayerDirection = spawnedPlayer.transform.forward;
		spawnedPlayerRotation = spawnedPlayer.transform.rotation;

    	Build();
    }

    void Build() {

    	int x = (int) Math.Truncate(spawnedPlayer.transform.position.x);
    	int y = (int) Math.Truncate(spawnedPlayer.transform.position.y);
    	int z = (int) Math.Truncate(spawnedPlayer.transform.position.z);

    	if(Input.GetKeyDown("b")) {

    		Debug.Log("Astronaut position x = " + x);
    		Debug.Log("Astronaut position y = " + y);
    		Debug.Log("Astronaut position z = " + z);

    		int newX = 0;
			int newY = 1;
			int newZ = 0;

			placedCubes.Add(GameObject.CreatePrimitive(PrimitiveType.Cube));
			placedCubes[placedCubes.Count - 1].transform.localScale = new Vector3(1, 1, 1);
			placedCubes[placedCubes.Count - 1].transform.position = spawnedPlayerPosition + spawnedPlayerDirection;

			newX = (int) Math.Truncate(placedCubes[placedCubes.Count - 1].transform.position.x);
    		newY += (int) Math.Truncate(placedCubes[placedCubes.Count - 1].transform.position.y);
    		newZ = (int) Math.Truncate(placedCubes[placedCubes.Count - 1].transform.position.z);

    		placedCubes[placedCubes.Count - 1].transform.position = new Vector3(newX, newY, newZ);

    		if(placedCubes.Count > 2) {

    			for(int i = 0; i < placedCubes.Count - 1; i++) {

	    			if(placedCubes[placedCubes.Count - 1].transform.position == placedCubes[i].transform.position) {

	    				Debug.Log("Cube already exists in position " + placedCubes[placedCubes.Count - 1].transform.position);
	    				placedCubes[placedCubes.Count - 1].transform.position = new Vector3(newX, placedCubes[i].transform.position.y + 1, newZ);
	    			}
	    		}
    		}

    		placedCubes[placedCubes.Count - 1].GetComponent<Renderer>().material.color = colorList[UnityEngine.Random.Range(0, colorList.Count)];

    		gameController2.UpdatePoints(10);
    		
    		Debug.Log("Placed cube in position: " + placedCubes[placedCubes.Count - 1].transform.position);
    	}

    	if(Input.GetKeyDown("c")) {

    		placedCylinders.Add(GameObject.CreatePrimitive(PrimitiveType.Cylinder));
    		placedCylinders[placedCylinders.Count - 1].transform.localScale = new Vector3(1, 1, 1);
    		placedCylinders[placedCylinders.Count - 1].transform.position = spawnedPlayerPosition + spawnedPlayerDirection;

    		int newX = (int) Math.Truncate(placedCylinders[placedCylinders.Count - 1].transform.position.x);
    		int newY = (int) Math.Truncate(placedCylinders[placedCylinders.Count - 1].transform.position.y);
    		int newZ = (int) Math.Truncate(placedCylinders[placedCylinders.Count - 1].transform.position.z);

    		placedCylinders[placedCylinders.Count - 1].transform.position = new Vector3(newX, newY + 1, newZ);

    		if(placedCylinders.Count > 2) {

    			for(int i = 0; i < placedCylinders.Count - 1; i++) {

	    			if(placedCylinders[placedCylinders.Count - 1].transform.position == placedCylinders[i].transform.position) {

	    				Debug.Log("Cylinder already exists in position " + placedCylinders[placedCylinders.Count - 1].transform.position);
	    				placedCylinders[placedCylinders.Count - 1].transform.position = new Vector3(newX, placedCylinders[i].transform.position.y + 1, newZ);
	    			}
	    		}
    		}

    		placedCylinders[placedCylinders.Count - 1].GetComponent<Renderer>().material.color = Color.cyan;

    		gameController2.UpdatePoints(20);

    		Debug.Log("Placed cylinder in position: " + placedCylinders[placedCylinders.Count - 1].transform.position);
    	}
    }
}